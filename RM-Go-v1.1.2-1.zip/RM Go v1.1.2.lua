-- RateMaster-Go
-- v1.1.2 

-- Copies specified SpeedMaster's value to specified RateMaster to treat it as a
-- "Go" button for any executors assigned to it.

-- Created by Jason Giaffo
-- Last updated Jul 4, 2019
-- Contact: http://giaffodesigns.com/contact/
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    local userconfig = {}
-- All copies and revisions of this code are copyright property of Giaffo Designs and may not be used, in any part or in entirety, without written consent of Jason Giaffo and credit where used. This plugin is only approved for usage by persons who have directly purchased it from GiaffoDesigns.
-- TL;DR: don't be a dick; don't steal people's work; give credit to people


userconfig.EFFECT_REF = '_REF BPM'       -- dummy effect referencing the desired SpeedMaster to copy from.
userconfig.RM    = 1                    -- RateMaster number that the plugin will copy the speed to.
userconfig.BEATS = 0                    -- how many beats will pass before the RateMaster returns to 0. Math expressions (i.e. 4*8) are valid.
                                        -- a value of 0 disables this feature and leaves it at the new value for the user to pull down








userconfig.VERBOSE = true               -- set to true to have the assessed rate print to the System Monitor each time.




--------------------------------------------------------------------------------------------
------------------------------ DO NOT EDIT BELOW THIS POINT --------------------------------
--------------------------------------------------------------------------------------------


---- Local Functions ----
local function cmd(...)
    gma.cmd(string.format(...))
end

local function echo(...)
    gma.echo(string.format(...))
end

local function feedback(...)
    gma.feedback(string.format(...))
end

local print = function(...)
    echo(...);
    feedback(...);
end

local function v_print(...)
    if userconfig.VERBOSE then
        local str = string.format(...)
        gma.echo(str)
        gma.feedback(str)
    end
end


local get_prop = function(obj, ref)    
    -- ref can be str:name or num:index
    return gma.show.property.get(gma.show.getobj.handle(obj), ref)
end


local function rate_assign(rate, percent)
    local full, half = 256, 128
    if percent then full, half = 100, 50; end;
    
    if     (rate > 1)  then return (full - (half/rate));
    elseif (rate < 1)  then return (half * rate);
    elseif (rate == 1) then return half; end;
end


local function Main()
   
    local bpm = get_prop('Effect 1."'..userconfig.EFFECT_REF..'".1', 'Speed')                                       -- extract speed value as property
    bpm = tonumber(bpm:match('%d+'))
    if (bpm == 0) then                                                                                              -- skip funciton if rate is at 0
        gui.print(gui.tcol.magenta..'REFERENCED SPEED MASTER IS STOPPED. RATE MASTER COPY NOT EXECUTED.')
        goto EOF                                         
    end
    
    local rate = bpm/60
    local rate_val = rate_assign(rate)              -- convert assignment-command value
    
    local time = (60/bpm) * userconfig.BEATS        -- sleep period
    local time_str = tostring(time)
    if (time == 0) then time_str = 'DISABLED'; end;
    
    cmd('SpecialMaster 4.%d At %.3f', userconfig.RM, rate_val)
    v_print('[35mBPM:  '..bpm)
    v_print('[35mRate: '..rate)
    v_print('[35mSleep Time: '..time_str)
    if userconfig.BEATS > 0 then
        gma.sleep(time)
        cmd('SpecialMaster 4.%d At 0', userconfig.RM)
    end
    
    ::EOF::
end



return Main