--[[
DMX ID - v1.1.2

-- Sends DMX commands to flash the number of each universe, to be read with a data tester (DMXcat, Swisson, RDM2Go, etc.)
-- Use for identifying DMX lines of unknown source.
-- Especially useful for larger install situations, and rigs using DMX-over-ethernet,
   such as using NPU's, PathPorts, and ArtNet-in fixtures.

Created by Jason Giaffo
Contact: GiaffoDesigns.com/contact/
Last updated September 24, 2017
Tested on versions 3.1.2, 3.2.2, 3.3.2 and 3.3.4.1
--]]





------------------------------------------------------------------
--------------------------- USER CONFIG --------------------------
---- (things you may want to change, depending on your needs) ----
------------------------------------------------------------------


local ignore_universes = {}     -- insert universe numbers to skip
                                -- (example: {1} ignores universe 1; {1, 3} ignores universes 1 and 3)

local match_channel = false     -- trigger corresponding channel within universe (ex: assign value to 3.003 instead of 3.1)
                                --\\ false (ex: information sent to 1.001, 2.001, 3.001...)
                                --\\ true  (ex: information sent to 1.001, 2.002, 3.003...)

local readout_percent = false   -- trigger values as percentage (0-100), rather than decimal (0-255)
                                --\\ values - true, false (no comma, do not use quotes)
								
								
								
local sleep_period = 0.8        -- sleep period between cycles when running, measured in seconds
                                -- you generally should not need to adjust this





								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
--------------------------------------------------------------------------------------------------------------------------
---------------------------------------------- DO NOT EDIT BELOW THIS POINT ----------------------------------------------
--------------------------------------------------------------------------------------------------------------------------

local msgbox = function(title, message_box, message_text)
  -- v. 1.0
  -- function avoids using confirmation box function with version 3.1.2.5, where it doesn't exist
  local confirm_method
  
  local version = gma.show.getvar('version')
  
  if version:find('3.1.2') == 1 then 
	confirm_method = 'textinput'
  else 
	confirm_method = 'box' end
  
  if confirm_method == 'box' then
	gma.gui.msgbox(title, message_box)
  elseif confirm_method == 'textinput' then
	gma.textinput(title, message_text)
  end
end

local univ = {}


local readout_mult
if readout_percent then readout_mult = 1
else readout_mult = (100/255) end



math.int_round = function(num)
	if (num - math.floor(num)) < 0.5 then return math.floor(num)
	else return math.ceil(num) end
end


local function DMXtest()
	univ.start = tonumber(gma.textinput('Starting Universe?', 1));	if not univ.start then goto EOF end;
	univ.final = tonumber(gma.textinput('Last Universe?', 16));		if not univ.final then goto EOF end;
	univ.ignore = {}
	for i, v in ipairs(ignore_universes) do
		univ.ignore[v] = true
	end

	-- create a list with all universes to be triggered
	univ.list = {}
	local muted = {}
	for i = univ.start, univ.final do
		if univ.ignore[i] then 
			muted[#muted+1] = i
		else
			-- set values to be triggered during test
			local universe = i
			local channel = 1
			local value = (i*readout_mult)
			
			if match_channel then
				channel = i
				value = 100
			end
			
			univ.list[#univ.list+1] = {univ = universe, ch = channel, value = value}
		end
	end
	
	if #muted > 0 then
		msgbox('Warning: Ignored Universes', 'Universe '..table.concat(muted, ' + ')..' set as \n"ignored" in UserConfig of plugin.', 'Userconfig set to ignore Univ '..table.concat(muted, ' + '))
	end
	
	
	-- loop flashing of DMX values
	if not match_channel then
		local loop = 1
		local set = 1
		local on = {}
		local off = {}
		for _, v in ipairs(univ.list) do
			if not on[set] then
				on[set] = {}
				off[set] = {}
			end
			
			on[set][loop] = 'DMX '..v.univ..'.'..v.ch..' At '..v.value
			off[set][loop] = 'DMX '..v.univ..'.'..v.ch..' At 0'
			
			if loop >= 64 then
				loop = 1
				set = set + 1
			else
				loop = loop + 1
			end
		end
		
		-- flashing number loop
		while true do
			-- trigger on
			for _, v in ipairs(on) do
				gma.cmd(table.concat(v, '; '))
				gma.sleep(0.01)
			end
			gma.sleep(sleep_period)
			
			-- release
			for _, v in ipairs(off) do
				gma.cmd(table.concat(v, '; '))
				gma.sleep(0.01)
			end
			gma.sleep(sleep_period)
		end
		
	-- for "match channel" mode	
	else
		local obj_tbl = {}
		for i, v in ipairs(univ.list) do
			obj_tbl[#obj_tbl+1] = v.univ..'.'..v.ch
		end
		local obj_str = table.concat(obj_tbl, ' + ')
		
		while true do
			gma.cmd('DMX '..obj_str..' At 100')
			gma.sleep(sleep_period)
			
			gma.cmd('DMX '..obj_str..' At 0')
			gma.sleep(sleep_period)		
		end
	end
	
	::EOF::
end


local function cleanup()
	local off_tbl = {}
	for _, v in ipairs(univ.list) do
		off_tbl[#off_tbl+1] = v.univ..'.'..v.ch
	end
	gma.cmd('Off DMX '..table.concat(off_tbl, ' + '))
end

return DMXtest, cleanup