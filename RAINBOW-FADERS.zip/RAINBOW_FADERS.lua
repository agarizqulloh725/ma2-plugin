--[[
WE PROUDLY PRESENT
THE ONLY PLUGIN PEOPLE WILL GET EXCITED ABOUT
WITH THE RELEASE OF V3.3.4.1

RAINBOW FADERS
Created by Jason Giaffo
find potentially-useful plugins at: GiaffoDesigns.com/plugins/

--]]


-------------------------------------------------------------------------
------------------------------ USER CONFIG ------------------------------
-------------------------------------------------------------------------



---- Config ----

local interval = 15             -- size of gap between color values. Higher value = shorter gaps between colors		
local faderct = 15              -- number of faders covered. 30 runs fairly poor.
local sleep_period = 0.05       -- time between each set of color commands. Poor performance below 0.05 seconds for 15 faders
local direction = 2             -- 1 for left, 2 for right















---- Editing below this point not advised.
---- But's it's a fuckin rainbow so do whatever you want.

local function phaseshift(current, max, reverse)
	-- function to move to next step of process, making a "bridge" between the starting and ending steps
	if not reverse then
		if current < max then return (current + 1)
		else return 1 end
	elseif reverse then
		if current > 1 then return (current - 1)
		else return max end		
	end
end
	
	
local function boost(list, interval)
	local phase = list.phase	-- just for shorthand
	
	-- set minumu and maximum values of range
	local max = 100
	local min = 0
	
	-- declare variables whose values will be assigned in IF statement
	local mult
	local tgt
	
	-- pseudo-table for color to adjust and direction to adjust in. Pretty sure this can be done more cleanly.
	if 		phase == 1 then tgt = 'g'; mult = 1;
	elseif	phase == 2 then tgt = 'r'; mult = -1;
	elseif	phase == 3 then tgt = 'b'; mult = 1;
	elseif	phase == 4 then tgt = 'g'; mult = -1;
	elseif	phase == 5 then tgt = 'r'; mult = 1;
	elseif	phase == 6 then tgt = 'b'; mult = -1;
	end
	
	local excess = 0	-- declare outside of IF statement
	list[tgt] = list[tgt] + (interval * mult)	-- assign new color value
	if list[tgt] > max or list[tgt] < min then											-- if value has passed bounds
		if mult == 1 then excess = math.abs(list[tgt] - max); list[tgt] = max;			-- calculate excess, pull within bounds
		else 			  excess = math.abs(min - list[tgt]); list[tgt] = min end
		
		list.phase = phaseshift(phase, 6)												-- change phase of process
		boost(list, excess)																-- calculate change in next color value using excess
	elseif list[tgt] == max or list[tgt] == min then 	-- change phase if limit has been hit
		list.phase = phaseshift(list.phase, 6)
	end

	
	-- no return, list is already updated
end


local color = {r = 100, g = 0, b = 0, phase = 1}

---- Main Function ----
local function rainbows()
	-- confirm plugin execution
	local confirm = gma.gui.confirm('Are You Sure?', 'Running this plugin will wipe your existing\npage\'s executor colors.\nProceed?')
	if not confirm then goto EOF end
	
	local cmd_list = {}												-- list where command strings will be stored
	local int = math.ceil(math.abs(interval))						-- interval variable. Set as separate from user input to properly round to whole numbers if user wants to be a smartass
	local total = math.ceil((100/int) * 6)							-- total number of commands to be generated to complete a loop

	-- popoulate command list
	for i = 1, total do
		cmd_list[i] = '/r='..tostring(color.r)..' /g='..tostring(color.g)..' /b='..tostring(color.b)
		boost(color, int)
	end

	-- trigger variable in case the "reverse" option was enabled
	local dir_cmd = false
	if direction > 1 then dir_cmd = true end

	-- step for first executor in list
	local start = 1
	
	while true do
		local clr = start		-- color (index value to be pulled for each executor individually)
		local cmd_line = {}		-- table for command to be passed to GMA
		
		-- populate table with command for each executor
		for i = 1, faderct do
			cmd_line[#cmd_line+1] = 'Appearance Executor '..tostring(i)..' '..cmd_list[clr]..'; '
			clr = phaseshift(clr, total)
		end
		
		gma.cmd(table.concat(cmd_line))		-- consolidate to single line and pass to GMA for execution
		start = phaseshift(start, total, dir_cmd)	-- bump up/down color command for first executor
		gma.sleep(sleep_period)				-- give the CPU a breath
	end
	
	::EOF::
end

local function cleanup()
	-- return all executors to no-appearance state
	gma.cmd('Appearance Executor 1 Thru '..faderct..' /r')
end


return rainbows, cleanup

